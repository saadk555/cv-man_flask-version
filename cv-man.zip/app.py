from ast import dump
from flask import * 
import flask
from glob import glob 
import os
from io import BytesIO
from zipfile import ZipFile
from flask import after_this_request
import io
import  flask_login
from flask_login import *



users = {'foo@bar.tld': {'password': 'secret'}}



UPLOAD_FOLDER = r"D:\xamppnew\htdocs\cv-man\UPLOAD_FOLDER"
ALLOWED_EXTENSIONS = 'pdf'


app = Flask(__name__)
app.secret_key = 'super secret string' 
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 5 * 1000 * 1000
app.secret_key = r'Hereyougoagain6757#$68' 
app.static_folder = 'static'
login_manager = LoginManager()
login_manager.init_app(app)


keyword = []

class User(flask_login.UserMixin):
    pass


@login_manager.user_loader
def user_loader(email):
    if email not in users:
        return

    user = User()
    user.id = email
    return user


@login_manager.request_loader
def request_loader(request):
    email = request.form.get('email')
    if email not in users:
        return

    user = User()
    user.id = email
    return user



@app.route('/login', methods=['GET', 'POST'])
def login():
    if flask.request.method == 'GET':
        return '''
               <form action='login' method='POST'>
                <input type='text' name='email' id='email' placeholder='email'/>
                <input type='password' name='password' id='password' placeholder='password'/>
                <input type='submit' name='submit'/>
               </form>
               '''

    email = flask.request.form['email']
    if email in users and flask.request.form['password'] == users[email]['password']:
        user = User()
        user.id = email
        flask_login.login_user(user)
        return flask.redirect(flask.url_for('protected'))

    return 'Bad login'


@app.route('/logout')
def logout():
    flask_login.logout_user()
    return 'Logged out'


@app.route('/protected')
@flask_login.login_required
def protected():
    return 'Logged in as: ' + flask_login.current_user.id

@app.route('/')  
@login_required
def index(): 
    return render_template("index.html")  

@app.route('/success', methods = ['POST'])  
@login_required
def success():  
    if request.method == 'POST':  
        f = request.files.getlist("file")
        for i in f:
            i.save(os.path.join(app.config['UPLOAD_FOLDER'], i.filename))  
        key = request.form['k']  
        return render_template("keywords.html", number = int(key))  



@app.route('/submitted', methods = ['POST']) 
@login_required
def submitted():
    from main import mainf  
    if request.method == 'POST':
        keyword.append(request.form.getlist('kw'))
        mainf(keyword)
        re = r'D:\xamppnew\htdocs\cv-man\result\\'
        with ZipFile(r"D:\xamppnew\htdocs\cv-man\result\result.zip", 'w') as zip:
            for file in glob(os.path.join(re, '*.pdf')):
                zip.write(file, os.path.basename(file))
        return render_template("result.html")



@app.route('/result', methods = ['GET']) 
@login_required
def result(): 
    zipfile = glob(r"D:\xamppnew\htdocs\cv-man\result\*")
    fname = glob(r"D:\xamppnew\htdocs\cv-man\UPLOAD_FOLDER\*.pdf")
    file_path = r"D:\xamppnew\htdocs\cv-man\result\result.zip"
    rd = io.BytesIO()
    if request.method == 'GET':
        with open(file_path, 'rb') as fo:
            rd.write(fo.read())
        rd.seek(0)
#for loops to remove ramining files
        os.remove(file_path)
        for i in fname: 
            if os.path.isfile(i):
                os.remove(i)
        for k in zipfile: 
            if os.path.isfile(k):
                os.remove(k)      
        #This sends the data stored in buffer to the user
        return send_file(rd, mimetype='application/zip',
                     download_name='result.zip')


@login_manager.unauthorized_handler
def unauthorized_handler():
    return 'Unauthorized', 401

    

if __name__ == '__main__':  
    app.run(host= 'localhost', debug = True) 


