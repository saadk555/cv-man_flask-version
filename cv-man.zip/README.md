CV-MAN
--------

#  Flask-based version of CV-MAN which can be deployed over web


- Upload all the resumes and enter amount of words you'd like to find

- Enter words one by one on next page

- wait for the result page download your result in zip


For more information, please refer back to the MASTER branch's readme file


----------------------------------------------------
External Libraries used in this project 


pytesseract 0.3.10
`pip install pytesseract`


pdf2image 1.16.0
`pip install pdf2image`


Pillow 9.2.0
`pip install Pillow`

Libraries and their uses are covered by their respective licenses in [Libraries](https://github.com/saadk555/cv-man/tree/master/Libraries) directory 

----------------------------------------------------

Feel free to contribute and improve it.

Any contribution would be highly appreciated.

----------------------------------------------------




